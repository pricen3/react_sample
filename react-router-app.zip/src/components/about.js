import React, {Component} from 'react';

class About extends Component {
    render(){
      return ( <div className='page' >
          <h4>About Component</h4>
          <div className='pageContent'>
              We are an evil corporation HAHAHA!
          </div>
      </div>);
    }
  }
  
  export default About;