import React, {Component} from 'react';
import {BrowserRouter, Route, Redirect, Link} from 'react-router-dom';
import './App.css';
import Home from './home'
import About from './about'

class App extends Component {
  render(){
    return (
    <BrowserRouter>
      <div>
        <h3>React Router App</h3>
        <nav>
          <Link to="/home">Home</Link>&nbsp;
          <Link to="/about">About</Link>
        </nav>
        <Redirect exact from="/" to="/home" />
        <Route path='/home' component={Home}/>
        <br></br>
        <Route path='/about' component={About}/>
      </div>
    </BrowserRouter>);
  }
}

export default App;
